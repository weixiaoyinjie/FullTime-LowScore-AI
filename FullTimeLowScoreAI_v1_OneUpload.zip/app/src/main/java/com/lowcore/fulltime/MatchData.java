package com.lowcore.fulltime;

import java.util.*;

public final class MatchData {
  public long id;
  public int homeId,awayId;
  public String home,away,league,country,kickoffUtc,status;
  public ScoreModel.Form homeForm,awayForm;
  public ScoreModel.Result prediction;
  public String failure="", oddsStatus="未查询",aiText="";
  public Map<String,Double> bet365Odds=new HashMap<>();
  public int homeGoals=-1,awayGoals=-1;
  public String title(){return home+" vs "+away;}
  public boolean hasData(){return prediction!=null;}
  public boolean complete(){return "FT".equals(status);}
  public double maxTargetEdge(double minOdds){
    if(prediction==null)return Double.NEGATIVE_INFINITY;
    double best=Double.NEGATIVE_INFINITY;
    for(String s:ScoreModel.TARGETS){Double odds=bet365Odds.get(s);if(odds!=null&&odds>=minOdds) best=Math.max(best,odds*prediction.probability(s)-1);}
    return best;
  }
  public String rating(double minOdds){
    if(prediction==null)return "PASS";
    if(bet365Odds.isEmpty())return prediction.under25>=0.65&&prediction.quality>=0.7?"C · 待核赔率":"PASS";
    double edge=maxTargetEdge(minOdds);
    if(edge>=0.12&&prediction.quality>=0.8&&prediction.under25>=0.68)return "B · 未校准";
    if(edge>=0.04&&prediction.quality>=0.6)return "C · 观察";
    return "PASS";
  }
}
