package com.lowcore.fulltime;

import android.content.*;
import org.json.*;
import java.util.*;

/** Local historical snapshots; snapshots never silently change when the model is updated. */
public final class ReviewStore {
  public static final String PREFS="low_score_preferences";
  private final SharedPreferences p;
  public ReviewStore(Context c){p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
  public String get(String name,String def){return p.getString(name,def);}
  public void put(String name,String value){p.edit().putString(name,value).apply();}
  public synchronized JSONArray all(){try{return new JSONArray(get("review_data","[]"));}catch(Exception e){return new JSONArray();}}
  public synchronized void saveWatch(MatchData m){
    if(m.prediction==null)return;
    JSONArray original=all(),newArray=new JSONArray();
    for(int i=0;i<original.length();i++){
      JSONObject o=original.optJSONObject(i);if(o!=null&&o.optLong("id")!=m.id)newArray.put(o);
    }
    JSONObject item=new JSONObject();
    try{
      item.put("id",m.id);item.put("home",m.home);item.put("away",m.away);item.put("league",m.league);
      item.put("country",m.country);item.put("kickoff",m.kickoffUtc);
      item.put("pick",m.prediction.topTarget());
      item.put("under25",m.prediction.under25);
      item.put("homeX",m.prediction.homeX);item.put("awayX",m.prediction.awayX);
      JSONObject probs=new JSONObject();for(String s:ScoreModel.TARGETS)probs.put(s,m.prediction.probability(s));
      JSONObject odds=new JSONObject();for(Map.Entry<String,Double> e:m.bet365Odds.entrySet())odds.put(e.getKey(),e.getValue());
      item.put("p",probs);item.put("odds",odds);
      item.put("savedAt",System.currentTimeMillis());item.put("settled",false);
      newArray.put(item);
      put("review_data",newArray.toString());
    }catch(JSONException ignored){}
  }
  public synchronized void settle(long id,int home,int away){
    JSONArray arr=all();for(int i=0;i<arr.length();i++){
      JSONObject o=arr.optJSONObject(i);if(o!=null&&o.optLong("id")==id){
        try{o.put("settled",true);o.put("homeFinal",home);o.put("awayFinal",away);o.put("settledAt",System.currentTimeMillis());}catch(JSONException ignored){}
      }
    }
    put("review_data",arr.toString());
  }
  public synchronized void delete(long id){
    JSONArray arr=all(),out=new JSONArray();for(int i=0;i<arr.length();i++){
      JSONObject o=arr.optJSONObject(i);if(o!=null&&o.optLong("id")!=id)out.put(o);
    }put("review_data",out.toString());
  }
}
