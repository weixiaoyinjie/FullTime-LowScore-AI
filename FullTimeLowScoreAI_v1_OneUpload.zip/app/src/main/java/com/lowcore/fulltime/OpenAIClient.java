package com.lowcore.fulltime;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Prototype BYOK only; production apps should proxy requests through a controlled backend. */
public final class OpenAIClient {
  public static String analyze(String key,MatchData m)throws Exception{
    if(key==null||key.trim().isEmpty())throw new IOException("请在设置中填写 OpenAI API Key");
    if(m.prediction==null)throw new IOException("比赛缺少可用统计模型数据");
    StringBuilder facts=new StringBuilder();
    facts.append("赛前比赛:").append(m.title()).append("\n联赛:").append(m.country).append(" / ").append(m.league)
      .append("\n开球:").append(m.kickoffUtc)
      .append("\n基线预期进球:").append(String.format(java.util.Locale.US,"%.3f, %.3f",m.prediction.homeX,m.prediction.awayX))
      .append("\n小2.5球概率:").append(String.format(java.util.Locale.US,"%.3f",m.prediction.under25))
      .append("\n最近有效完赛场次:").append(m.homeForm.matches).append(",").append(m.awayForm.matches);
    for(String s:ScoreModel.TARGETS){facts.append("\n").append(s).append(" 基线概率=").append(String.format(java.util.Locale.US,"%.4f",m.prediction.probability(s)));
      if(m.bet365Odds.containsKey(s))facts.append(" Bet365赔率=").append(m.bet365Odds.get(s));else facts.append(" Bet365赔率=缺失");
    }
    facts.append("\n注意：当前输入未包含xG、伤停、阵容、比赛动量或球队实际对手强度，这些因素不能臆造。");
    JSONObject req=new JSONObject();req.put("model","gpt-4.1-mini");
    req.put("store",false);
    req.put("instructions","你是谨慎的足球比分研究分析员。严格只使用输入事实，禁止编造数据、实时情况、阵容、xG、赔率。用简体中文回答：①为何倾向/不倾向低比分 ②最大风险 ③最高概率的两个目标比分及其模型概率 ④市场价格是否有可研究价差（仅当有真实赔率）⑤ PASS/C观察/B候选（不允许给A） ⑥仍需验证的数据。强调基线未完成校准，不得保证命中。100到220字。");
    req.put("input",facts.toString());
    HttpURLConnection c=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
    try{
      c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(45000);
      c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key.trim());
      try(OutputStream o=c.getOutputStream()){o.write(req.toString().getBytes(StandardCharsets.UTF_8));}
      int status=c.getResponseCode();InputStream stream=status>=200&&status<300?c.getInputStream():c.getErrorStream();
      ByteArrayOutputStream out=new ByteArrayOutputStream();if(stream!=null)try(InputStream in=stream){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>500000)break;}}
      String response=new String(out.toByteArray(),StandardCharsets.UTF_8);
      if(status!=200)throw new IOException("AI HTTP "+status+"："+response.substring(0,Math.min(250,response.length())));
      JSONObject json=new JSONObject(response);StringBuilder t=new StringBuilder();
      JSONArray msgs=json.optJSONArray("output");if(msgs!=null)for(int i=0;i<msgs.length();i++){
        JSONObject item=msgs.optJSONObject(i);if(item==null||!"message".equals(item.optString("type")))continue;
        JSONArray contents=item.optJSONArray("content");if(contents==null)continue;
        for(int j=0;j<contents.length();j++){
          JSONObject part=contents.optJSONObject(j);if(part!=null&&"output_text".equals(part.optString("type")))t.append(part.optString("text"));
        }
      }
      if(t.length()==0)throw new IOException("AI没有返回可显示的文字");
      return t.toString();
    }finally{c.disconnect();}
  }
}
