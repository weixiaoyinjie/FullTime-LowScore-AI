package com.lowcore.fulltime;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
  private final int BG=Color.rgb(10,17,30),CARD=Color.rgb(21,32,50),SECOND=Color.rgb(150,165,188);
  private final int WHITE=Color.rgb(239,246,255),ACCENT=Color.rgb(73,208,160),LINE=Color.rgb(45,61,82);
  private ReviewStore store;
  private LinearLayout root,body,content,tabBar;
  private TextView stateLabel;
  private EditText dateField,countField,poolField,minOddField;
  private String section="扫描";
  private final List<MatchData> matches=Collections.synchronizedList(new ArrayList<>());
  private volatile boolean scanning=false;
  private int doneCount=0,selectedCount=0,outputCount=20;
  private final ExecutorService background=Executors.newFixedThreadPool(3);
  private double minOdds=3;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);store=new ReviewStore(this);render();}
  @Override protected void onDestroy(){background.shutdownNow();super.onDestroy();}
  private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));if(stroke!=0)g.setStroke(dp(1),stroke);return g;}
  private TextView txt(String text,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(text);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private void pad(View v,int p){v.setPadding(dp(p),dp(p),dp(p),dp(p));}
  private void addGap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
  private TextView button(String name,Runnable r,boolean bright){TextView t=txt(name,14,bright?BG:WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(12),dp(12),dp(12));t.setBackground(shape(bright?ACCENT:CARD,bright?0:LINE,11));t.setOnClickListener(v->r.run());return t;}
  private TextView note(String x){return txt(x,12,SECOND,false);}
  private EditText entry(String value,String hint,int inputType){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setTextColor(WHITE);e.setHintTextColor(SECOND);e.setBackground(shape(CARD,LINE,9));e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setHint(hint);e.setInputType(inputType);e.setText(value);return e;}
  private LinearLayout card(){LinearLayout c=col();pad(c,14);c.setBackground(shape(CARD,LINE,14));return c;}
  private void render(){
    root=col();root.setBackgroundColor(BG);setContentView(root);
    LinearLayout header=col();header.setPadding(dp(17),dp(18),dp(17),dp(11));
    header.addView(txt("FULLTIME  LOWSCORE  AI",19,WHITE,true));header.addView(note("整场低比分雷达 · v1.0 · 仅研究信号"));root.addView(header);
    tabBar=row();tabBar.setPadding(dp(10),0,dp(10),dp(8));root.addView(tabBar);
    for(String name:new String[]{"扫描","观察","复盘","设置"}){
      TextView btn=button(name,()->{section=name;render();},name.equals(section));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.setMargins(dp(3),0,dp(3),0);tabBar.addView(btn,lp);
    }
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    body=col();body.setPadding(dp(13),dp(8),dp(13),dp(18));scroll.addView(body);
    switch(section){case "设置":settings();break;case "复盘":reviews();break;case "观察":watchPanel();break;default:scanner();}
  }
  private void scanner(){
    LinearLayout c=card();body.addView(c);
    c.addView(txt("赛前自动扫描",17,WHITE,true));addGap(c,8);
    c.addView(note("按比赛日期读取真实赛程；只分析尚未开赛、且有足够完赛记录的比赛。"));addGap(c,12);
    dateField=entry(store.get("scan_date",LocalDate.now(ZoneId.of("America/Argentina/Buenos_Aires")).toString()),"YYYY-MM-DD",InputType.TYPE_CLASS_DATETIME|InputType.TYPE_DATETIME_VARIATION_DATE);
    c.addView(note("比赛日期（阿根廷时间）"));c.addView(dateField);addGap(c,8);
    LinearLayout opts=row();countField=entry(store.get("count","20"),"20",InputType.TYPE_CLASS_NUMBER);
    poolField=entry(store.get("pool","30"),"30",InputType.TYPE_CLASS_NUMBER);
    minOddField=entry(store.get("min_odd","3.0"),"3.0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
    LinearLayout left=col(),right=col();left.addView(note("输出前N场"));left.addView(countField);right.addView(note("候选抽样场数"));right.addView(poolField);
    LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);half.setMargins(0,0,dp(7),0);opts.addView(left,half);opts.addView(right,new LinearLayout.LayoutParams(0,-2,1));c.addView(opts);addGap(c,8);c.addView(note("最低目标比分赔率（只影响已获取赔率后的筛选）"));c.addView(minOddField);
    addGap(c,11);
    TextView go=button("扫描并计算概率",this::startScan,true);c.addView(go);addGap(c,8);
    stateLabel=note(scanning?"扫描中："+doneCount+" / "+selectedCount:"请求预算约1+2×候选场数；从全天赛程均匀抽样，不保证全量覆盖");c.addView(stateLabel);
    addGap(body,12);
    content=col();body.addView(content);showMatches();
  }
  private void startScan(){
    if(scanning){toast("扫描正在进行中");return;}
    String dt=dateField.getText().toString().trim();int count,pool;double min;
    try{LocalDate day=LocalDate.parse(dt);if(day.isBefore(LocalDate.now(ZoneId.of("America/Argentina/Buenos_Aires")))){toast("请使用今天或将来的日期，避免历史数据泄漏");return;}
      count=Integer.parseInt(countField.getText().toString().trim());pool=Integer.parseInt(poolField.getText().toString().trim());min=Double.parseDouble(minOddField.getText().toString().trim().replace(',','.'));
      if(count<1||count>40||pool<count||pool>60||min<1.01||min>500)throw new IllegalArgumentException();
    }catch(Exception e){toast("日期YYYY-MM-DD，输出1～40，抽样场数≥输出且≤60，赔率1.01～500");return;}
    String key=store.get("football_key","");if(key.isEmpty()){new AlertDialog.Builder(this).setTitle("尚未配置足球API").setMessage("先在设置中填入 API-Football Key，再开始扫描。").setPositiveButton("设置",(d,w)->{section="设置";render();}).setNegativeButton("取消",null).show();return;}
    store.put("scan_date",dt);store.put("count",String.valueOf(count));store.put("pool",String.valueOf(pool));store.put("min_odd",String.valueOf(min));minOdds=min;outputCount=count;
    scanning=true;doneCount=0;selectedCount=pool;matches.clear();showMatches();setState("正在获取赛程...");
    final ApiFootballClient api=new ApiFootballClient(key);
    new Thread(()->{
      try{
        List<MatchData> found=api.fixtures(dt);found.sort(Comparator.comparing(m->m.kickoffUtc));
        int n=Math.min(pool,found.size());selectedCount=n;
        if(n==0){scanning=false;runOnUiThread(()->setState("该日期没有符合条件的未开赛比赛"));return;}
        runOnUiThread(()->setState("全天找到"+found.size()+"场待赛比赛，均匀抽样"+n+"场；目标展示前"+outputCount+"场"));
        List<MatchData> sample=new ArrayList<>();
        for(int i=0;i<n;i++){int ix=(int)Math.floor((i+0.5)*found.size()/n);sample.add(found.get(Math.min(found.size()-1,ix)));}
        List<Future<?>> jobs=new ArrayList<>();
        for(int i=0;i<n;i++){
          MatchData m=sample.get(i);
          jobs.add(background.submit(()->{
            try{
              Instant kickoff=OffsetDateTime.parse(m.kickoffUtc).toInstant();
              m.homeForm=api.teamForm(m.homeId,true,kickoff);m.awayForm=api.teamForm(m.awayId,false,kickoff);
              m.prediction=ScoreModel.calculate(m.homeForm,m.awayForm);
            }catch(Exception e){m.failure=safeMessage(e);}
            matches.add(m);int complete;
            synchronized(MainActivity.this){doneCount++;complete=doneCount;}
            runOnUiThread(()->{if("扫描".equals(section)){setState("已完成 "+complete+" / "+selectedCount+"，可用模型 "+validCount()+" 场");showMatches();}});
          }));
        }
        for(Future<?> f:jobs)try{f.get();}catch(Exception ignored){}
        scanning=false;runOnUiThread(()->{if("扫描".equals(section)){setState("扫描结束：模型可用 "+validCount()+" / "+selectedCount+"；赔率需逐场查询，不自动补造");showMatches();}});
      }catch(Exception e){scanning=false;String msg=safeMessage(e);runOnUiThread(()->{setState("扫描失败："+msg);toast("接口错误，查看提示");});}
    },"scan-thread").start();
  }
  private int validCount(){int total=0;synchronized(matches){for(MatchData m:matches)if(m.hasData())total++;}return total;}
  private void setState(String s){if(stateLabel!=null)stateLabel.setText(s);}
  private String safeMessage(Exception e){String s=e.getMessage();return s==null?e.getClass().getSimpleName():s.length()>250?s.substring(0,250):s;}
  private void showMatches(){
    if(content==null)return;content.removeAllViews();
    List<MatchData> sorted; synchronized(matches){sorted=new ArrayList<>(matches);}
    sorted.sort((a,b)->{
      if(a.hasData()!=b.hasData())return a.hasData()?-1:1;
      if(a.hasData()&&b.hasData())return Double.compare(b.prediction.under25,a.prediction.under25);
      return a.kickoffUtc.compareTo(b.kickoffUtc);
    });
    if(sorted.isEmpty()){content.addView(note("扫描结果将在这里展示。"));return;}
    content.addView(txt("候选列表 · 按低进球概率排序",16,WHITE,true));addGap(content,8);
    int displayed=0;
    for(MatchData m:sorted){
      if(displayed++>=outputCount)break;
      LinearLayout c=card();LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(9);content.addView(c,lp);
      c.addView(note(SpanishNames.competition(m)+"   |   "+formatDate(m.kickoffUtc)));
      c.addView(txt(m.title(),15,WHITE,true));addGap(c,7);
      if(m.hasData()){
        c.addView(txt(String.format(Locale.US,"小2.5球 %.1f%%    核心4比分 %.1f%%",100*m.prediction.under25,100*m.prediction.core),16,ACCENT,true));
        c.addView(note("最高目标 "+m.prediction.topTarget()+"  ·  "+m.rating(minOdds)+"  ·  "+m.oddsStatus));
      }else c.addView(note("PASS · "+(m.failure.isEmpty()?"计算中":m.failure)));
      addGap(c,9);c.addView(button("查看比分概率 / 赔率 / AI分析",()->showDetail(m),false));
    }
  }
  private String formatDate(String iso){try{return OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.of("America/Argentina/Buenos_Aires")).format(DateTimeFormatter.ofPattern("MM-dd HH:mm"));}catch(Exception e){return iso;}}
  private void showDetail(MatchData m){
    if(m.prediction==null){alert("没有评分",m.failure.isEmpty()?"该场仍在扫描中":m.failure);return;}
    LinearLayout panel=col();pad(panel,16);
    TextView main=txt("",14,WHITE,false);panel.addView(main);
    Runnable refresh=()->main.setText(details(m));refresh.run();
    LinearLayout ctrls=col();addGap(ctrls,10);
    ctrls.addView(button("读取实际 Bet365 准确比分赔率",()->{
      toast("正在查询真实赔率...");background.submit(()->{
        try{Map<String,Double> odds=new ApiFootballClient(store.get("football_key","")).oddsBet365(m.id);
          m.bet365Odds=odds;m.oddsStatus=odds.isEmpty()?"接口无Bet365准确比分赔率":"已读取Bet365";
          runOnUiThread(()->{refresh.run();showMatches();});
        }catch(Exception e){m.oddsStatus="赔率失败: "+safeMessage(e);runOnUiThread(()->refresh.run());}
      });
    },false));addGap(ctrls,6);
    ctrls.addView(button("AI 解释（按需调用付费API）",()->{
      toast("AI分析请求中...");background.submit(()->{
        try{String result=OpenAIClient.analyze(store.get("openai_key",""),m);m.aiText=result;runOnUiThread(()->refresh.run());}
        catch(Exception e){runOnUiThread(()->alert("AI请求失败",safeMessage(e)));}
      });
    },false));addGap(ctrls,6);
    ctrls.addView(button("主单＋保险单盈亏模拟",()->calculator(m),false));addGap(ctrls,6);
    ctrls.addView(button("保存预测快照到复盘",()->{store.saveWatch(m);toast("已保存，之后可核对终场比分");},true));
    panel.addView(ctrls);
    ScrollView sc=new ScrollView(this);sc.addView(panel);
    AlertDialog dialog=new AlertDialog.Builder(this).setTitle(m.title()).setView(sc).setPositiveButton("关闭",(d,w)->{}).create();dialog.show();
  }
  private String details(MatchData m){
    StringBuilder s=new StringBuilder();ScoreModel.Result r=m.prediction;
    s.append(SpanishNames.competition(m)).append("\n").append(formatDate(m.kickoffUtc)).append("  阿根廷时间\n\n");
    s.append(String.format(Locale.US,"预期进球（非xG）: 主 %.2f / 客 %.2f\n",r.homeX,r.awayX));
    s.append(String.format(Locale.US,"整场小2.5: %.1f%% | 0-0/1-0/0-1/1-1合计: %.1f%%\n",100*r.under25,100*r.core));
    s.append("模型：基础进球均值 + Dixon-Coles修正；未做历史校准\n");
    s.append("历史有效完赛: ").append(m.homeForm.matches).append(" / ").append(m.awayForm.matches).append("场\n");
    s.append("\n目标比分    模型概率     Bet365赔率     参考EV\n");
    for(String p:ScoreModel.TARGETS){Double odd=m.bet365Odds.get(p);
      s.append(String.format(Locale.US,"%-6s        %5.1f%%         %s",p,100*r.probability(p),odd==null?"缺失":String.format(Locale.US,"%.2f",odd)));
      if(odd!=null)s.append(String.format(Locale.US,"        %+.1f%%",100*(odd*r.probability(p)-1)));
      s.append("\n");
    }
    s.append("\n当前评级：").append(m.rating(minOdds)).append("\n赔率状态：").append(m.oddsStatus)
      .append("\n没有真实赔率时不判断价格优势；理论EV不是已验证优势。\n")
      .append("\n最大风险：球队近期样本有限、未校正对手强度，缺少阵容、伤停及真实xG。\n");
    if(!m.aiText.isEmpty())s.append("\n【AI解释】\n").append(m.aiText);
    return s.toString();
  }
  private void calculator(MatchData m){
    List<String> available=new ArrayList<>();
    for(String s:ScoreModel.TARGETS)if(m.bet365Odds.containsKey(s))available.add(s);
    if(available.size()<2){alert("赔率不足","需要先读取到至少两个实际Bet365准确比分赔率，才能计算主单和保险单。不会用虚构赔率代替。");return;}
    String main=m.prediction.topTarget();if(!available.contains(main))main=available.get(0);
    final String mainPick=main;
    LinearLayout v=col();pad(v,15);v.addView(note("主单："+mainPick+" / "+m.bet365Odds.get(mainPick)+"；其余已报价比分按相同中奖毛回报进行对冲。"));addGap(v,10);
    EditText stake=entry(store.get("stake","10000"),"主单金额",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);v.addView(stake);
    addGap(v,6);v.addView(note("保险单最多选2张；所需金额 = 主单金额×主单赔率÷保险赔率"));
    new AlertDialog.Builder(this).setTitle("组合盈亏（同场互斥结果）").setView(v)
      .setPositiveButton("计算",(d,w)->{
        double amount;try{amount=Double.parseDouble(stake.getText().toString());if(amount<=0||amount>1e8)throw new Exception();}catch(Exception e){toast("金额无效");return;}
        store.put("stake",String.valueOf(amount));
        List<String> alt=new ArrayList<>(available);alt.remove(mainPick);
        alt.sort((a,b)->Double.compare(m.prediction.probability(b),m.prediction.probability(a)));
        if(alt.size()>2)alt=alt.subList(0,2);
        double gross=amount*m.bet365Odds.get(mainPick),total=amount;StringBuilder sb=new StringBuilder();
        sb.append(String.format(Locale.US,"主单 %s：本金 %.2f，赔率 %.2f\n",mainPick,amount,m.bet365Odds.get(mainPick)));
        for(String s:alt){double vAlt=gross/m.bet365Odds.get(s);total+=vAlt;sb.append(String.format(Locale.US,"保险 %s：金额 %.2f，赔率 %.2f\n",s,vAlt,m.bet365Odds.get(s)));}
        sb.append(String.format(Locale.US,"\n全部投入：%.2f\n任何一个已覆盖比分出现：净收益 %+.2f\n其余比分：净亏损 -%.2f",total,gross-total,total));
        sb.append("\n\n此例按等毛回报配置，不保证保本；若覆盖结果赔率倒数之和≥1，覆盖内也无法实现无风险盈利。未包含手续费、限额或赔率变化。");
        alert("组合盈亏演算",sb.toString());
      }).setNegativeButton("取消",null).show();
  }
  private void watchPanel(){
    LinearLayout c=card();body.addView(c);c.addView(txt("重点观察",19,WHITE,true));addGap(c,8);
    c.addView(note("在扫描页点击比赛，按需获取Bet365赔率、查看全部比分概率并调用AI。通过‘保存预测快照’进入复盘。"));
    addGap(body,12);TextView go=button("打开扫描列表",()->{section="扫描";render();},true);body.addView(go);
    addGap(body,14);body.addView(txt("筛选标准",16,WHITE,true));addGap(body,7);
    body.addView(note("A级暂时关闭：没有历史概率校准和样本外验证时，不能宣称高置信优势。B级仅为未校准的模型候选；盘口缺失时一律不认定价值投注。"));
  }
  private void reviews(){
    LinearLayout h=card();body.addView(h);h.addView(txt("预测记录与终场复盘",18,WHITE,true));addGap(h,6);
    JSONArray list=store.all();int settled=0,correct=0;double brier=0;int bN=0;
    for(int i=0;i<list.length();i++){JSONObject o=list.optJSONObject(i);if(o==null||!o.optBoolean("settled"))continue;settled++;
      int hg=o.optInt("homeFinal"),ag=o.optInt("awayFinal");if(o.optString("pick").equals(hg+"-"+ag))correct++;
      double p=o.optDouble("under25",0);int obs=hg+ag<=2?1:0;brier+=(p-obs)*(p-obs);bN++;
    }
    h.addView(txt("记录 "+list.length()+" 场  ·  已结算 "+settled+" 场  ·  首选比分命中 "+correct+" 场",14,WHITE,true));
    if(bN>0)h.addView(note(String.format(Locale.US,"小2.5球 Brier Score：%.4f（越低越好，需与基准比较）",brier/bN)));
    addGap(body,10);
    if(list.length()==0){body.addView(note("暂无记录。到扫描页保存候选赛前预测，避免赛后修改历史概率。"));return;}
    for(int i=list.length()-1;i>=0;i--){JSONObject o=list.optJSONObject(i);if(o==null)continue;
      final long id=o.optLong("id");LinearLayout c=card();LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);body.addView(c,lp);
      c.addView(txt(o.optString("home")+" vs "+o.optString("away"),15,WHITE,true));
      c.addView(note(o.optString("country")+" · "+o.optString("league")+"\n"+formatDate(o.optString("kickoff"))));
      String result=o.optBoolean("settled")?(o.optInt("homeFinal")+"-"+o.optInt("awayFinal")):"未结算";
      c.addView(txt("预测 "+o.optString("pick")+" → 实际 "+result,14,o.optBoolean("settled")?ACCENT:SECOND,true));
      c.addView(note(String.format(Locale.US,"赛前小2.5概率 %.1f%%",o.optDouble("under25")*100)));
      addGap(c,8);LinearLayout controls=row();
      TextView sync=button("查询终场",()->{toast("查询中...");background.submit(()->{
        try{int[] res=new ApiFootballClient(store.get("football_key","")).result(id);
          runOnUiThread(()->{if(res!=null){store.settle(id,res[0],res[1]);render();}else toast("该场尚未取得FT终场数据");});
        }catch(Exception e){runOnUiThread(()->alert("无法查询",safeMessage(e)));}
      });},false);
      controls.addView(sync,new LinearLayout.LayoutParams(0,dp(44),1));
      TextView del=button("删除",()->new AlertDialog.Builder(this).setTitle("删除此记录？").setPositiveButton("删除",(d,w)->{store.delete(id);render();}).setNegativeButton("取消",null).show(),false);
      LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),0.7f);p.leftMargin=dp(6);controls.addView(del,p);c.addView(controls);
    }
  }
  private void settings(){
    LinearLayout c=card();body.addView(c);c.addView(txt("API连接设置",19,WHITE,true));addGap(c,10);
    c.addView(note("足球API：API-SPORTS / API-Football v3"));addGap(c,5);
    EditText football=entry(store.get("football_key",""),"x-apisports-key",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);c.addView(football);addGap(c,11);
    c.addView(note("OpenAI API（仅点击单场AI分析才调用）"));addGap(c,5);
    EditText openai=entry(store.get("openai_key",""),"sk-...",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);c.addView(openai);addGap(c,10);
    c.addView(button("保存连接配置",()->{store.put("football_key",football.getText().toString().trim());store.put("openai_key",openai.getText().toString().trim());toast("配置已保存在此设备应用私有空间");},true));
    addGap(body,12);LinearLayout info=card();body.addView(info);
    info.addView(txt("数据声明与风险",17,WHITE,true));addGap(info,8);
    info.addView(note("· 只支持API-SPORTS Football v3格式；不同足球API服务商的Key不能直接通用。\n\n· Bet365赔率以API实时可取字段为准；未覆盖时显示缺失。赔率不属于预测模型输入。\n\n· 进球均值由近期进球/失球构造，不是真实xG；固定修正参数尚未进行联赛级校准。\n\n· API Key仅存应用私有SharedPreferences，未进行硬件密钥加密；本版仅适合个人测试，正式发布前应把OpenAI请求放到自己的安全服务端。\n\n· 不承诺准确比分命中率或持续盈利。"));
    addGap(body,10);body.addView(button("模型离线示例（非真实比赛）",()->{
      ScoreModel.Result r=ScoreModel.calculateRates(1.0,0.7,1);
      StringBuilder s=new StringBuilder("主队1.0球、客队0.7球的演示分布\n\n");
      for(String score:ScoreModel.TARGETS)s.append(score).append(String.format(Locale.US,"  %.1f%%\n",r.probability(score)*100));
      s.append(String.format(Locale.US,"\n整场小2.5概率：%.1f%%",r.under25*100));alert("仅供验证模型",s.toString());
    },false));
  }
  private void alert(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("确定",null).show();}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
