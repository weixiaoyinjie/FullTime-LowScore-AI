package com.lowcore.fulltime;
import java.util.*;
/** Display names only; preserve source-league identity and do not invent competition mapping. */
public final class SpanishNames {
  private static final Map<String,String> COUNTRIES = new HashMap<>();
  static {
    String[][] list={{"England","Inglaterra"},{"Spain","España"},{"Germany","Alemania"},
      {"Italy","Italia"},{"France","Francia"},{"Brazil","Brasil"},{"Netherlands","Países Bajos"},
      {"Scotland","Escocia"},{"Belgium","Bélgica"},{"Turkey","Turquía"},
      {"Switzerland","Suiza"},{"United States","Estados Unidos"},{"Greece","Grecia"},
      {"Austria","Austria"},{"Czech-Republic","República Checa"}};
    for(String[] pair:list)COUNTRIES.put(pair[0],pair[1]);
  }
  public static String country(String s){return COUNTRIES.getOrDefault(s,s);}
  public static String competition(MatchData m){return country(m.country)+" · "+m.league;}
  private SpanishNames(){}
}
