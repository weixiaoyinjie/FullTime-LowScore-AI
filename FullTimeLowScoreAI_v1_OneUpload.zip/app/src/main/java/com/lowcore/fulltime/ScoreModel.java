package com.lowcore.fulltime;

import java.util.*;

/** Transparent, uncalibrated baseline. No causal guarantee or odds-based recalibration. */
public final class ScoreModel {
  public static final String[] TARGETS = {"0-0", "1-0", "0-1", "1-1"};
  public static final class Score {
    public final String name;
    public final double probability;
    Score(String name, double probability) { this.name=name; this.probability=probability; }
  }
  public static final class Result {
    public final double homeX,awayX,under25,core,quality;
    public final List<Score> scores;
    Result(double homeX,double awayX,double under25,double core,double quality,List<Score> scores) {
      this.homeX=homeX;this.awayX=awayX;this.under25=under25;this.core=core;this.quality=quality;
      this.scores=Collections.unmodifiableList(scores);
    }
    public double probability(String s) { for (Score x:scores) if(x.name.equals(s))return x.probability; return 0; }
    public String topTarget() {String best="0-0";double p=-1;for(String s:TARGETS){double v=probability(s);if(v>p){p=v;best=s;}}return best;}
  }
  public static final class Form {
    public final int matches;
    public final double forAvg,againstAvg,homeAwayForAvg,homeAwayAgainstAvg;
    public final int venueMatches;
    public Form(int matches,double forAvg,double againstAvg,int venueMatches,double homeAwayForAvg,double homeAwayAgainstAvg){
      this.matches=matches;this.forAvg=forAvg;this.againstAvg=againstAvg;this.venueMatches=venueMatches;
      this.homeAwayForAvg=homeAwayForAvg;this.homeAwayAgainstAvg=homeAwayAgainstAvg;
    }
  }
  private static double bound(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
  private static double[] poisson(double lambda,int max){
    double[] a=new double[max+1];a[0]=Math.exp(-lambda);
    for(int i=1;i<=max;i++)a[i]=a[i-1]*lambda/i;
    return a;
  }
  public static Result calculate(Form home,Form away){
    if(home.matches<5||away.matches<5)throw new IllegalArgumentException("双方至少各5场完赛记录");
    // Shrink venue sub-samples towards full 10-match form; league priors are generic, not competition-specific.
    double hw=bound(home.venueMatches/8.0,0,0.55);
    double aw=bound(away.venueMatches/8.0,0,0.55);
    double hAttack=home.forAvg*(1-hw)+home.homeAwayForAvg*hw;
    double hDefense=home.againstAvg*(1-hw)+home.homeAwayAgainstAvg*hw;
    double aAttack=away.forAvg*(1-aw)+away.homeAwayForAvg*aw;
    double aDefense=away.againstAvg*(1-aw)+away.homeAwayAgainstAvg*aw;
    double sample=bound(Math.min(home.matches,away.matches)/12.0,0,0.8);
    double lambda=bound((0.55*hAttack+0.45*aDefense)*sample+1.35*(1-sample),0.20,3.4);
    double mu=bound((0.55*aAttack+0.45*hDefense)*sample+1.12*(1-sample),0.20,3.4);
    return calculateRates(lambda,mu,Math.min(home.matches,away.matches)/10.0);
  }
  public static Result calculateRates(double lambda,double mu,double sampleQuality){
    if(!Double.isFinite(lambda)||!Double.isFinite(mu)||lambda<=0||mu<=0)throw new IllegalArgumentException("进球均值必须为正有限数");
    final int n=10;
    double[] h=poisson(lambda,n),a=poisson(mu,n);
    double[][] arr=new double[n+1][n+1];
    double sum=0;
    // Dixon-Coles low-goal interaction (rho=-0.08), fixed provisional value; requires later backtest calibration.
    final double rho=-0.08;
    for(int i=0;i<=n;i++)for(int j=0;j<=n;j++){
      double tau=1;
      if(i==0&&j==0)tau=1-lambda*mu*rho;
      else if(i==0&&j==1)tau=1+lambda*rho;
      else if(i==1&&j==0)tau=1+mu*rho;
      else if(i==1&&j==1)tau=1-rho;
      arr[i][j]=Math.max(0,h[i]*a[j]*tau);
      sum+=arr[i][j];
    }
    List<Score> outcomes=new ArrayList<>();double u=0,core=0;
    for(int i=0;i<=n;i++)for(int j=0;j<=n;j++){
      double p=arr[i][j]/sum;
      if(i+j<=2)u+=p;
      String s=i+"-"+j;
      if(Arrays.asList(TARGETS).contains(s))core+=p;
      outcomes.add(new Score(s,p));
    }
    outcomes.sort((x,y)->Double.compare(y.probability,x.probability));
    return new Result(lambda,mu,u,core,bound(sampleQuality,0,1),outcomes);
  }
  private ScoreModel(){}
}
