package com.lowcore.fulltime;

import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;

public final class ApiFootballClient {
  private final String token;
  public ApiFootballClient(String token){this.token=token.trim();}
  private JSONObject get(String path) throws Exception {
    if(token.isEmpty())throw new IOException("请先在设置中填写足球 API Key");
    HttpURLConnection conn=(HttpURLConnection)new URL("https://v3.football.api-sports.io/"+path).openConnection();
    try{
      conn.setConnectTimeout(15000);conn.setReadTimeout(20000);conn.setRequestProperty("x-apisports-key",token);
      conn.setRequestProperty("Accept","application/json");
      int status=conn.getResponseCode();
      InputStream stream=status>=200&&status<300?conn.getInputStream():conn.getErrorStream();
      String body=read(stream);
      if(status!=200)throw new IOException("足球API HTTP "+status+" "+body.substring(0,Math.min(180,body.length())));
      JSONObject obj=new JSONObject(body);
      Object errors=obj.opt("errors");
      if(errors instanceof JSONArray && ((JSONArray)errors).length()>0)throw new IOException("足球API错误："+errors);
      if(errors instanceof JSONObject && ((JSONObject)errors).length()>0)throw new IOException("足球API错误："+errors);
      return obj;
    }finally{conn.disconnect();}
  }
  private static String read(InputStream is)throws IOException{
    if(is==null)return "";try(InputStream in=is; ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>6_000_000)throw new IOException("响应太大");}
      return new String(out.toByteArray(),StandardCharsets.UTF_8);
    }
  }
  public List<MatchData> fixtures(String date) throws Exception {
    JSONArray arr=get("fixtures?date="+URLEncoder.encode(date,"UTF-8")+"&timezone=America%2FArgentina%2FBuenos_Aires").optJSONArray("response");
    List<MatchData> list=new ArrayList<>();if(arr==null)return list;
    for(int i=0;i<arr.length();i++){
      JSONObject o=arr.getJSONObject(i),f=o.optJSONObject("fixture"),teams=o.optJSONObject("teams"),league=o.optJSONObject("league");
      if(f==null||teams==null||league==null)continue;
      String status=f.optJSONObject("status")==null?"":f.getJSONObject("status").optString("short");
      if(!"NS".equals(status))continue;
      String leagueName=league.optString("name");
      String search=leagueName.toLowerCase(Locale.ROOT);
      if(search.contains("friendly")||search.contains("amistoso")||search.contains("u19")||search.contains("u20")||search.contains("u21")||search.contains("youth")||search.contains("reserve"))continue;
      JSONObject home=teams.optJSONObject("home"),away=teams.optJSONObject("away");if(home==null||away==null)continue;
      MatchData m=new MatchData();m.id=f.optLong("id");m.homeId=home.optInt("id");m.awayId=away.optInt("id");
      m.home=home.optString("name");m.away=away.optString("name");m.league=leagueName;m.country=league.optString("country");
      m.kickoffUtc=f.optString("date");m.status=status;
      if(m.id>0&&m.homeId>0&&m.awayId>0)list.add(m);
    }
    return list;
  }
  public ScoreModel.Form teamForm(int teamId,boolean homeVenue,Instant before) throws Exception{
    JSONArray arr=get("fixtures?team="+teamId+"&last=12").optJSONArray("response");
    if(arr==null)throw new IOException("没有球队历史数据");
    int n=0,venueN=0;double scored=0,conceded=0,venueScored=0,venueConceded=0;
    for(int i=0;i<arr.length();i++){
      JSONObject game=arr.optJSONObject(i);if(game==null)continue;
      JSONObject fixture=game.optJSONObject("fixture"),teams=game.optJSONObject("teams"),goals=game.optJSONObject("goals");
      if(fixture==null||teams==null||goals==null)continue;
      if(!"FT".equals(fixture.optJSONObject("status")==null?"":fixture.getJSONObject("status").optString("short")))continue;
      try{if(!Instant.parse(fixture.optString("date")).isBefore(before))continue;}catch(Exception ignored){continue;}
      JSONObject gh=teams.optJSONObject("home"),ga=teams.optJSONObject("away");if(gh==null||ga==null)continue;
      boolean isHome=gh.optInt("id")==teamId;
      if(!isHome&&ga.optInt("id")!=teamId)continue;
      if(goals.isNull("home")||goals.isNull("away"))continue;
      int h=goals.optInt("home",-1),a=goals.optInt("away",-1);if(h<0||a<0)continue;
      int gf=isHome?h:a, gc=isHome?a:h;scored+=gf;conceded+=gc;n++;
      if(isHome==homeVenue){venueN++;venueScored+=gf;venueConceded+=gc;}
      if(n>=10)break;
    }
    if(n<5)throw new IOException("有效完赛记录不足5场（"+n+"场）");
    return new ScoreModel.Form(n,scored/n,conceded/n,venueN,venueN==0?scored/n:venueScored/venueN,venueN==0?conceded/n:venueConceded/venueN);
  }
  /** Fetch only on demand. Never infer bookmaker ID; match sportsbook name from actual response. */
  public Map<String,Double> oddsBet365(long fixtureId)throws Exception{
    JSONObject json=get("odds?fixture="+fixtureId);
    JSONArray response=json.optJSONArray("response");
    Map<String,Double> values=new HashMap<>();
    if(response==null)return values;
    int pages=Math.min(3,json.optJSONObject("paging")==null?1:json.getJSONObject("paging").optInt("total",1));
    for(int p=1;p<=pages;p++){
      JSONArray rs=p==1?response:get("odds?fixture="+fixtureId+"&page="+p).optJSONArray("response");
      if(rs==null)continue;
      for(int i=0;i<rs.length();i++){
        JSONObject obj=rs.optJSONObject(i);if(obj==null)continue;
        JSONArray books=obj.optJSONArray("bookmakers");if(books==null)continue;
        for(int b=0;b<books.length();b++){
          JSONObject book=books.optJSONObject(b);if(book==null||!book.optString("name").toLowerCase(Locale.ROOT).contains("bet365"))continue;
          JSONArray bets=book.optJSONArray("bets");if(bets==null)continue;
          for(int k=0;k<bets.length();k++){
            JSONObject bet=bets.optJSONObject(k);if(bet==null)continue;
            String name=bet.optString("name").toLowerCase(Locale.ROOT);
            if(!(name.contains("correct score")||name.contains("exact score")||name.contains("resultado exacto")))continue;
            JSONArray odds=bet.optJSONArray("values");if(odds==null)continue;
            for(int j=0;j<odds.length();j++){
              JSONObject val=odds.optJSONObject(j);if(val==null)continue;
              String score=val.optString("value").replace(":","-").replaceAll("\\s+","").trim();
              String odd=val.optString("odd").replace(",",".");
              for(String s:ScoreModel.TARGETS)if(s.equals(score))try{
                double dec=Double.parseDouble(odd);if(dec>1&&dec<1000)values.put(s,dec);
              }catch(NumberFormatException ignored){}
            }
          }
        }
      }
    }
    return values;
  }
  public int[] result(long fixtureId)throws Exception{
    JSONArray arr=get("fixtures?id="+fixtureId).optJSONArray("response");
    if(arr==null||arr.length()==0)return null;
    JSONObject game=arr.getJSONObject(0),fixture=game.getJSONObject("fixture"),goals=game.getJSONObject("goals");
    if(!"FT".equals(fixture.getJSONObject("status").optString("short")))return null;
    if(goals.isNull("home")||goals.isNull("away"))return null;
    return new int[]{goals.getInt("home"),goals.getInt("away")};
  }
}
