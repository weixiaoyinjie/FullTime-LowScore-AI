# FullTime LowScore AI · 整场低比分雷达 v1.0

原生 Android（Java）研究版，独立包名 `com.lowcore.fulltime`，与其他 APK 可并行安装。

## 已实现

- API-FOOTBALL v3（API-SPORTS）的日期赛程，排除未开赛以外的状态、常见友谊赛与青年比赛。
- 默认输出 20 场，全天等间距抽样 30 场（可调整至60场）；仅对抽样比赛排序，不宣称覆盖全天所有比赛。
- 每队读取最多12条历史比赛，从其中最多10场有效 FT 记录估计主客进球率；每队至少需5场。
- 基于泊松与固定 Dixon-Coles 低比分参数（rho=-0.08）的**未校准基线**：0-0、1-0、0-1、1-1和整场小2.5概率。
- 逐场按需查询 `/odds?fixture=id` 的 Bet365 Correct Score 盘口；按博彩公司**实际名称**核对，未命中显示无赔率；不混入其他平台赔率，不伪造数据。
- 真实赔率下展示未经校准的理论EV；未验证前不提供 A 评级。
- 单场按需调用 OpenAI Responses API（模型 `gpt-4.1-mini`），禁止AI编造 xG、阵容、伤停、赔率等缺失数据。
- 主单固定金额、最多两张保险单按等毛回报计算，展示覆盖内外不同结果的实际组合盈亏。
- 保存赛前预测快照、手动刷新 FT 终场、Brier Score 简易复盘。
- 日期、数量、赔率阈值、主单金额和两个 API Key 在本机保存。
- 展示部分常用国家的西班牙语名称，联赛名称保留API原名避免错误匹配。

## 不包含／后续版本

- **不包含真实xG**：当前数据仅来自球队历史进球与失球，界面中明确标注“预期进球（非xG）”。
- 不包含联赛强度分层、对手质量校正、首发阵容、伤停、直播15/30分钟动态更新、历史概率校准、自动赌注执行或自动通知。
- 对赔率的读取按需进行；API 无 Bet365 Correct Score 盘口时显示“缺失”。
- 比分概率**没有**经过样本外检验，不能理解为胜率或盈利保证。
- 不使用真实付费数据进行过端到端联网测试，需配置自己的 Keys，在真实设备上验证API数据覆盖。

## 使用准备

1. 在“设置”输入 API-SPORTS / API-Football v3 的足球 API Key（请求头 `x-apisports-key`）。**其他供应商的同名足球API不保证兼容。**
2. 可选填 OpenAI API Key，点单场“AI 解释”时才触发付费请求；不填时计算不受影响。
3. 在“扫描”选择阿根廷日期、展示前N场、候选抽样场数及最低Bet365准确比分赔率（只影响赔率评分）；点击“扫描并计算概率”。
4. 点击单场获取 Bet365 Correct Score 赔率，再查看评级及理论价差。
5. 保存预测快照，在比赛FT后去“复盘”查询终场。

## API预算

一次扫描约 `1 + 2 × 候选数` 次足球 API 请求（没有共享缓存） + 单场赔率按需至少1次（部分响应分页会额外调用）。默认候选30场则约61次请求，需留意你的API套餐配额。

## 安全与隐私

测试版两个 API Key 保存在 Android 应用私有 SharedPreferences，`allowBackup=false`，HTTPS传输。**这不是硬件级密钥保护**：不要分发填过密钥的App或共享秘钥；产品化必须引入自己的后端代发 OpenAI 请求，增加认证、限速及密钥管理。

## GitHub Actions 一键编译

将 `FullTimeLowScoreAI_v1_OneUpload.zip` 上传至仓库**根目录**。再在 `.github/workflows/build-apk.yml` 路径创建或更新与本包附带的同名文件（另提供独立 YAML 下载）。打开 Actions → `Build FullTime LowScore AI APK v1` → Run workflow。等运行成功后，点 Artifacts 下载 `FullTimeLowScoreAI-v1-debug-apk`，解压拿到 `app-debug.apk`。

构建环境：Ubuntu 24.04 + Java 17 + AGP 8.7.3 + Gradle 8.9 + Android SDK 35。无需 Gradle Wrapper 文件。

## 本地运行概率计算测试

```bash
mkdir -p out
javac -d out app/src/main/java/com/lowcore/fulltime/ScoreModel.java tests/ScoreModelSelfTest.java
java -cp out ScoreModelSelfTest
```
