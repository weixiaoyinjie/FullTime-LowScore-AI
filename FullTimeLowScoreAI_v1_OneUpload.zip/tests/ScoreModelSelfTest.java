import com.lowcore.fulltime.ScoreModel;

public class ScoreModelSelfTest {
  private static void verify(boolean b,String reason){if(!b)throw new AssertionError(reason);}
  public static void main(String[] args){
    ScoreModel.Result base=ScoreModel.calculateRates(1.0,0.7,1.0);
    verify(base.under25>0.7&&base.under25<0.85,"under 2.5 range");
    verify(base.core>0.4&&base.core<0.7,"target probability range");
    verify(base.probability("0-0")>0,"0-0 positive");
    double sum=0;for(ScoreModel.Score s:base.scores)sum+=s.probability;
    verify(Math.abs(sum-1)<1e-9,"normalized grid");
    verify(base.probability(base.topTarget())>=base.probability("0-1"),"best target");
    ScoreModel.Result high=ScoreModel.calculateRates(2.8,2.2,0.8);
    verify(high.under25<base.under25,"high scoring lower under");
    ScoreModel.Result low=ScoreModel.calculateRates(0.4,0.3,0.9);
    verify(low.under25>base.under25,"low scoring higher under");
    ScoreModel.Form a=new ScoreModel.Form(10,0.8,0.7,5,0.7,0.6);
    ScoreModel.Form b=new ScoreModel.Form(10,0.6,1.1,5,0.5,1.3);
    ScoreModel.Result r=ScoreModel.calculate(a,b);
    verify(r.homeX>0.2&&r.awayX>0.2,"derived lambdas");
    try{ScoreModel.calculate(new ScoreModel.Form(2,1,1,1,1,1),b);throw new AssertionError("must reject short sample");}catch(IllegalArgumentException ok){}
    System.out.printf("OK | core=%.4f under25=%.4f top=%s rate=%.3f %.3f%n",base.core,base.under25,base.topTarget(),r.homeX,r.awayX);
  }
}
